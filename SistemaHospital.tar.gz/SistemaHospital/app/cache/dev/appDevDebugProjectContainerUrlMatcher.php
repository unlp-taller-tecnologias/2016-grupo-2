<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevDebugProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_purge
                if ($pathinfo === '/_profiler/purge') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:purgeAction',  '_route' => '_profiler_purge',);
                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        if (0 === strpos($pathinfo, '/admin/a')) {
            if (0 === strpos($pathinfo, '/admin/anestesia')) {
                // admin_anestesia_index
                if (rtrim($pathinfo, '/') === '/admin/anestesia') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_anestesia_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_anestesia_index');
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\AnestesiaController::indexAction',  '_route' => 'admin_anestesia_index',);
                }
                not_admin_anestesia_index:

                // admin_anestesia_new
                if ($pathinfo === '/admin/anestesia/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_admin_anestesia_new;
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\AnestesiaController::newAction',  '_route' => 'admin_anestesia_new',);
                }
                not_admin_anestesia_new:

                // admin_anestesia_show
                if (preg_match('#^/admin/anestesia/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_anestesia_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_anestesia_show')), array (  '_controller' => 'AppBundle\\Controller\\AnestesiaController::showAction',));
                }
                not_admin_anestesia_show:

                // admin_anestesia_edit
                if (preg_match('#^/admin/anestesia/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_admin_anestesia_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_anestesia_edit')), array (  '_controller' => 'AppBundle\\Controller\\AnestesiaController::editAction',));
                }
                not_admin_anestesia_edit:

                // admin_anestesia_delete
                if (preg_match('#^/admin/anestesia/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_admin_anestesia_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_anestesia_delete')), array (  '_controller' => 'AppBundle\\Controller\\AnestesiaController::deleteAction',));
                }
                not_admin_anestesia_delete:

            }

            if (0 === strpos($pathinfo, '/admin/asa')) {
                // admin_asa_index
                if (rtrim($pathinfo, '/') === '/admin/asa') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_asa_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_asa_index');
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\AsaController::indexAction',  '_route' => 'admin_asa_index',);
                }
                not_admin_asa_index:

                // admin_asa_new
                if ($pathinfo === '/admin/asa/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_admin_asa_new;
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\AsaController::newAction',  '_route' => 'admin_asa_new',);
                }
                not_admin_asa_new:

                // admin_asa_show
                if (preg_match('#^/admin/asa/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_asa_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_asa_show')), array (  '_controller' => 'AppBundle\\Controller\\AsaController::showAction',));
                }
                not_admin_asa_show:

                // admin_asa_edit
                if (preg_match('#^/admin/asa/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_admin_asa_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_asa_edit')), array (  '_controller' => 'AppBundle\\Controller\\AsaController::editAction',));
                }
                not_admin_asa_edit:

                // admin_asa_delete
                if (preg_match('#^/admin/asa/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_admin_asa_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_asa_delete')), array (  '_controller' => 'AppBundle\\Controller\\AsaController::deleteAction',));
                }
                not_admin_asa_delete:

            }

        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        if (0 === strpos($pathinfo, '/admin')) {
            if (0 === strpos($pathinfo, '/admin/estado')) {
                // admin_estado_index
                if (rtrim($pathinfo, '/') === '/admin/estado') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_estado_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_estado_index');
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\EstadoController::indexAction',  '_route' => 'admin_estado_index',);
                }
                not_admin_estado_index:

                // admin_estado_new
                if ($pathinfo === '/admin/estado/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_admin_estado_new;
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\EstadoController::newAction',  '_route' => 'admin_estado_new',);
                }
                not_admin_estado_new:

                // admin_estado_show
                if (preg_match('#^/admin/estado/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_estado_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_estado_show')), array (  '_controller' => 'AppBundle\\Controller\\EstadoController::showAction',));
                }
                not_admin_estado_show:

                // admin_estado_edit
                if (preg_match('#^/admin/estado/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_admin_estado_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_estado_edit')), array (  '_controller' => 'AppBundle\\Controller\\EstadoController::editAction',));
                }
                not_admin_estado_edit:

                // admin_estado_delete
                if (preg_match('#^/admin/estado/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_admin_estado_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_estado_delete')), array (  '_controller' => 'AppBundle\\Controller\\EstadoController::deleteAction',));
                }
                not_admin_estado_delete:

            }

            // personal_index
            if (rtrim($pathinfo, '/') === '/admin') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_personal_index;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'personal_index');
                }

                return array (  '_controller' => 'AppBundle\\Controller\\PersonalController::indexAction',  '_route' => 'personal_index',);
            }
            not_personal_index:

            // personal_new
            if ($pathinfo === '/admin/new') {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_personal_new;
                }

                return array (  '_controller' => 'AppBundle\\Controller\\PersonalController::newAction',  '_route' => 'personal_new',);
            }
            not_personal_new:

            // personal_show
            if (preg_match('#^/admin/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_personal_show;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'personal_show')), array (  '_controller' => 'AppBundle\\Controller\\PersonalController::showAction',));
            }
            not_personal_show:

            // personal_edit
            if (preg_match('#^/admin/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_personal_edit;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'personal_edit')), array (  '_controller' => 'AppBundle\\Controller\\PersonalController::editAction',));
            }
            not_personal_edit:

            // personal_delete
            if (preg_match('#^/admin/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'DELETE') {
                    $allow[] = 'DELETE';
                    goto not_personal_delete;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'personal_delete')), array (  '_controller' => 'AppBundle\\Controller\\PersonalController::deleteAction',));
            }
            not_personal_delete:

            if (0 === strpos($pathinfo, '/admin/quirofano')) {
                // admin_quirofano_index
                if (rtrim($pathinfo, '/') === '/admin/quirofano') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_quirofano_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_quirofano_index');
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\QuirofanoController::indexAction',  '_route' => 'admin_quirofano_index',);
                }
                not_admin_quirofano_index:

                // admin_quirofano_new
                if ($pathinfo === '/admin/quirofano/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_admin_quirofano_new;
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\QuirofanoController::newAction',  '_route' => 'admin_quirofano_new',);
                }
                not_admin_quirofano_new:

                // admin_quirofano_show
                if (preg_match('#^/admin/quirofano/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_quirofano_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_quirofano_show')), array (  '_controller' => 'AppBundle\\Controller\\QuirofanoController::showAction',));
                }
                not_admin_quirofano_show:

                // admin_quirofano_edit
                if (preg_match('#^/admin/quirofano/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_admin_quirofano_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_quirofano_edit')), array (  '_controller' => 'AppBundle\\Controller\\QuirofanoController::editAction',));
                }
                not_admin_quirofano_edit:

                // admin_quirofano_delete
                if (preg_match('#^/admin/quirofano/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_admin_quirofano_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_quirofano_delete')), array (  '_controller' => 'AppBundle\\Controller\\QuirofanoController::deleteAction',));
                }
                not_admin_quirofano_delete:

            }

        }

        if (0 === strpos($pathinfo, '/reserva')) {
            // reserva_index
            if (rtrim($pathinfo, '/') === '/reserva') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_reserva_index;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'reserva_index');
                }

                return array (  'page' => 1,  '_controller' => 'AppBundle\\Controller\\ReservaController::indexAction',  '_route' => 'reserva_index',);
            }
            not_reserva_index:

            // reserva_index_paginated
            if (0 === strpos($pathinfo, '/reserva/page') && preg_match('#^/reserva/page/(?P<page>[1-9]\\d*)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_reserva_index_paginated;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'reserva_index_paginated')), array (  '_controller' => 'AppBundle\\Controller\\ReservaController::indexAction',));
            }
            not_reserva_index_paginated:

        }

        if (0 === strpos($pathinfo, '/admin')) {
            if (0 === strpos($pathinfo, '/admin/rol')) {
                // admin_rol_index
                if (rtrim($pathinfo, '/') === '/admin/rol') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_rol_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_rol_index');
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\RolController::indexAction',  '_route' => 'admin_rol_index',);
                }
                not_admin_rol_index:

                // admin_rol_new
                if ($pathinfo === '/admin/rol/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_admin_rol_new;
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\RolController::newAction',  '_route' => 'admin_rol_new',);
                }
                not_admin_rol_new:

                // admin_rol_show
                if (preg_match('#^/admin/rol/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_rol_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_rol_show')), array (  '_controller' => 'AppBundle\\Controller\\RolController::showAction',));
                }
                not_admin_rol_show:

                // admin_rol_edit
                if (preg_match('#^/admin/rol/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_admin_rol_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_rol_edit')), array (  '_controller' => 'AppBundle\\Controller\\RolController::editAction',));
                }
                not_admin_rol_edit:

                // admin_rol_delete
                if (preg_match('#^/admin/rol/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_admin_rol_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_rol_delete')), array (  '_controller' => 'AppBundle\\Controller\\RolController::deleteAction',));
                }
                not_admin_rol_delete:

            }

            if (0 === strpos($pathinfo, '/admin/servicio')) {
                // admin_servicio_index
                if (rtrim($pathinfo, '/') === '/admin/servicio') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_servicio_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_servicio_index');
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\ServicioController::indexAction',  '_route' => 'admin_servicio_index',);
                }
                not_admin_servicio_index:

                // admin_servicio_new
                if ($pathinfo === '/admin/servicio/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_admin_servicio_new;
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\ServicioController::newAction',  '_route' => 'admin_servicio_new',);
                }
                not_admin_servicio_new:

                // admin_servicio_show
                if (preg_match('#^/admin/servicio/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_servicio_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_servicio_show')), array (  '_controller' => 'AppBundle\\Controller\\ServicioController::showAction',));
                }
                not_admin_servicio_show:

                // admin_servicio_edit
                if (preg_match('#^/admin/servicio/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_admin_servicio_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_servicio_edit')), array (  '_controller' => 'AppBundle\\Controller\\ServicioController::editAction',));
                }
                not_admin_servicio_edit:

                // admin_servicio_delete
                if (preg_match('#^/admin/servicio/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_admin_servicio_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_servicio_delete')), array (  '_controller' => 'AppBundle\\Controller\\ServicioController::deleteAction',));
                }
                not_admin_servicio_delete:

            }

            if (0 === strpos($pathinfo, '/admin/user')) {
                // user_index
                if (rtrim($pathinfo, '/') === '/admin/user') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_user_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'user_index');
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\UserController::indexAction',  '_route' => 'user_index',);
                }
                not_user_index:

                // user_new
                if (preg_match('#^/admin/user(?P<id_personal>[^/]++)/new$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_user_new;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'user_new')), array (  '_controller' => 'AppBundle\\Controller\\UserController::newAction',));
                }
                not_user_new:

                // user_show
                if (preg_match('#^/admin/user/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_user_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'user_show')), array (  '_controller' => 'AppBundle\\Controller\\UserController::showAction',));
                }
                not_user_show:

                // user_edit
                if (preg_match('#^/admin/user/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_user_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'user_edit')), array (  '_controller' => 'AppBundle\\Controller\\UserController::editAction',));
                }
                not_user_edit:

                // user_delete
                if (preg_match('#^/admin/user/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_user_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'user_delete')), array (  '_controller' => 'AppBundle\\Controller\\UserController::deleteAction',));
                }
                not_user_delete:

            }

        }

        if (0 === strpos($pathinfo, '/log')) {
            if (0 === strpos($pathinfo, '/login')) {
                // fos_user_security_login
                if ($pathinfo === '/login') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_security_login;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::loginAction',  '_route' => 'fos_user_security_login',);
                }
                not_fos_user_security_login:

                // fos_user_security_check
                if ($pathinfo === '/login_check') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_fos_user_security_check;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::checkAction',  '_route' => 'fos_user_security_check',);
                }
                not_fos_user_security_check:

            }

            // fos_user_security_logout
            if ($pathinfo === '/logout') {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_fos_user_security_logout;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::logoutAction',  '_route' => 'fos_user_security_logout',);
            }
            not_fos_user_security_logout:

        }

        if (0 === strpos($pathinfo, '/profile')) {
            // fos_user_profile_show
            if (rtrim($pathinfo, '/') === '/profile') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_fos_user_profile_show;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'fos_user_profile_show');
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::showAction',  '_route' => 'fos_user_profile_show',);
            }
            not_fos_user_profile_show:

            // fos_user_profile_edit
            if ($pathinfo === '/profile/edit') {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_fos_user_profile_edit;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::editAction',  '_route' => 'fos_user_profile_edit',);
            }
            not_fos_user_profile_edit:

        }

        if (0 === strpos($pathinfo, '/re')) {
            if (0 === strpos($pathinfo, '/register')) {
                // fos_user_registration_register
                if (rtrim($pathinfo, '/') === '/register') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_registration_register;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'fos_user_registration_register');
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::registerAction',  '_route' => 'fos_user_registration_register',);
                }
                not_fos_user_registration_register:

                if (0 === strpos($pathinfo, '/register/c')) {
                    // fos_user_registration_check_email
                    if ($pathinfo === '/register/check-email') {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_fos_user_registration_check_email;
                        }

                        return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::checkEmailAction',  '_route' => 'fos_user_registration_check_email',);
                    }
                    not_fos_user_registration_check_email:

                    if (0 === strpos($pathinfo, '/register/confirm')) {
                        // fos_user_registration_confirm
                        if (preg_match('#^/register/confirm/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                                $allow = array_merge($allow, array('GET', 'HEAD'));
                                goto not_fos_user_registration_confirm;
                            }

                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_registration_confirm')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmAction',));
                        }
                        not_fos_user_registration_confirm:

                        // fos_user_registration_confirmed
                        if ($pathinfo === '/register/confirmed') {
                            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                                $allow = array_merge($allow, array('GET', 'HEAD'));
                                goto not_fos_user_registration_confirmed;
                            }

                            return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmedAction',  '_route' => 'fos_user_registration_confirmed',);
                        }
                        not_fos_user_registration_confirmed:

                    }

                }

            }

            if (0 === strpos($pathinfo, '/resetting')) {
                // fos_user_resetting_request
                if ($pathinfo === '/resetting/request') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_fos_user_resetting_request;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::requestAction',  '_route' => 'fos_user_resetting_request',);
                }
                not_fos_user_resetting_request:

                // fos_user_resetting_send_email
                if ($pathinfo === '/resetting/send-email') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_fos_user_resetting_send_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::sendEmailAction',  '_route' => 'fos_user_resetting_send_email',);
                }
                not_fos_user_resetting_send_email:

                // fos_user_resetting_check_email
                if ($pathinfo === '/resetting/check-email') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_fos_user_resetting_check_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::checkEmailAction',  '_route' => 'fos_user_resetting_check_email',);
                }
                not_fos_user_resetting_check_email:

                // fos_user_resetting_reset
                if (0 === strpos($pathinfo, '/resetting/reset') && preg_match('#^/resetting/reset/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_resetting_reset;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_resetting_reset')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::resetAction',));
                }
                not_fos_user_resetting_reset:

            }

        }

        // fos_user_change_password
        if ($pathinfo === '/profile/change-password') {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_fos_user_change_password;
            }

            return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ChangePasswordController::changePasswordAction',  '_route' => 'fos_user_change_password',);
        }
        not_fos_user_change_password:

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
