<?php

/* Admin/partials/personal/new.html.twig */
class __TwigTemplate_1691f9af2ebf027c1b3d999361023df4e86215ce1050f429ad8ae83d8e800695 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Admin/layout.html.twig", "Admin/partials/personal/new.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "Admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e14e10705f45ed4ffd8aab43649a93fa6d8b5a2ae0d8ffa0686ad26aa1f137f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e14e10705f45ed4ffd8aab43649a93fa6d8b5a2ae0d8ffa0686ad26aa1f137f1->enter($__internal_e14e10705f45ed4ffd8aab43649a93fa6d8b5a2ae0d8ffa0686ad26aa1f137f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/partials/personal/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e14e10705f45ed4ffd8aab43649a93fa6d8b5a2ae0d8ffa0686ad26aa1f137f1->leave($__internal_e14e10705f45ed4ffd8aab43649a93fa6d8b5a2ae0d8ffa0686ad26aa1f137f1_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_35051536371f0935e135bfb5f19566205d206a4d3062f00d8103127b3da04af2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35051536371f0935e135bfb5f19566205d206a4d3062f00d8103127b3da04af2->enter($__internal_35051536371f0935e135bfb5f19566205d206a4d3062f00d8103127b3da04af2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/partials/personal/new.html.twig"));

        // line 4
        echo "    <h1>Personal creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("personal_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_35051536371f0935e135bfb5f19566205d206a4d3062f00d8103127b3da04af2->leave($__internal_35051536371f0935e135bfb5f19566205d206a4d3062f00d8103127b3da04af2_prof);

    }

    public function getTemplateName()
    {
        return "Admin/partials/personal/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Admin/layout.html.twig' %}

{% block main %}
    <h1>Personal creation</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input type=\"submit\" value=\"Create\" />
    {{ form_end(form) }}

    <ul>
        <li>
            <a href=\"{{ path('personal_index') }}\">Back to the list</a>
        </li>
    </ul>
{% endblock %}
", "Admin/partials/personal/new.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/partials/personal/new.html.twig");
    }
}
