<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_279240087872accc90fbaa3c13505507342cd4a65591817ce12bffa1d31e574f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3cb2463f998d1886165faa82bdfc1916300adac772eef9a0ab56a510028c7761 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3cb2463f998d1886165faa82bdfc1916300adac772eef9a0ab56a510028c7761->enter($__internal_3cb2463f998d1886165faa82bdfc1916300adac772eef9a0ab56a510028c7761_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3cb2463f998d1886165faa82bdfc1916300adac772eef9a0ab56a510028c7761->leave($__internal_3cb2463f998d1886165faa82bdfc1916300adac772eef9a0ab56a510028c7761_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_23eedde2615acd6c1b5c6d821c31ec55280a4a0021b07cfb7d74ad481875d685 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23eedde2615acd6c1b5c6d821c31ec55280a4a0021b07cfb7d74ad481875d685->enter($__internal_23eedde2615acd6c1b5c6d821c31ec55280a4a0021b07cfb7d74ad481875d685_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        
        $__internal_23eedde2615acd6c1b5c6d821c31ec55280a4a0021b07cfb7d74ad481875d685->leave($__internal_23eedde2615acd6c1b5c6d821c31ec55280a4a0021b07cfb7d74ad481875d685_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_bed0bbb3000efe2ea4dd27ebac146fb4275c7e4c107702b91033b6b4ba3dd368 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bed0bbb3000efe2ea4dd27ebac146fb4275c7e4c107702b91033b6b4ba3dd368->enter($__internal_bed0bbb3000efe2ea4dd27ebac146fb4275c7e4c107702b91033b6b4ba3dd368_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_bed0bbb3000efe2ea4dd27ebac146fb4275c7e4c107702b91033b6b4ba3dd368->leave($__internal_bed0bbb3000efe2ea4dd27ebac146fb4275c7e4c107702b91033b6b4ba3dd368_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_62e8c26129e5cb4e21d4639f13f575dd9a31ce04a77e23aba72a3ece8006a504 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_62e8c26129e5cb4e21d4639f13f575dd9a31ce04a77e23aba72a3ece8006a504->enter($__internal_62e8c26129e5cb4e21d4639f13f575dd9a31ce04a77e23aba72a3ece8006a504_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_62e8c26129e5cb4e21d4639f13f575dd9a31ce04a77e23aba72a3ece8006a504->leave($__internal_62e8c26129e5cb4e21d4639f13f575dd9a31ce04a77e23aba72a3ece8006a504_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/var/www/html/taller/SistemaHospital/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
