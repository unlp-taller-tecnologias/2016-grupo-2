<?php

/* Admin/partials/rol/index.html.twig */
class __TwigTemplate_e311fb5390ebee774f457fa499ff2bda6b993623af15f3b5295cf9fa761dafde extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Admin/layout.html.twig", "Admin/partials/rol/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "Admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1dee023e3f22c6cc6f00302347a4cf4b63eb6792102f3df931d3f61723e9d4e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1dee023e3f22c6cc6f00302347a4cf4b63eb6792102f3df931d3f61723e9d4e->enter($__internal_f1dee023e3f22c6cc6f00302347a4cf4b63eb6792102f3df931d3f61723e9d4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/partials/rol/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f1dee023e3f22c6cc6f00302347a4cf4b63eb6792102f3df931d3f61723e9d4e->leave($__internal_f1dee023e3f22c6cc6f00302347a4cf4b63eb6792102f3df931d3f61723e9d4e_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_1da857f44271fcf220d9c95a43a1eaa0094f34cf79ce5542170cf9a53ef49110 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1da857f44271fcf220d9c95a43a1eaa0094f34cf79ce5542170cf9a53ef49110->enter($__internal_1da857f44271fcf220d9c95a43a1eaa0094f34cf79ce5542170cf9a53ef49110_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/partials/rol/index.html.twig"));

        // line 4
        echo "    <h1>Roles lista</h1>
    ";
        // line 5
        if ( !twig_test_empty((isset($context["rols"]) ? $context["rols"] : $this->getContext($context, "rols")))) {
            // line 6
            echo "    <table class=\"table table-striped table-hover\">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nombre</th>
                <th>Baja</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        ";
            // line 17
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["rols"]) ? $context["rols"] : $this->getContext($context, "rols")));
            foreach ($context['_seq'] as $context["_key"] => $context["rol"]) {
                // line 18
                echo "            <tr>
                <td><a href=\"";
                // line 19
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_rol_show", array("id" => $this->getAttribute($context["rol"], "id", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["rol"], "id", array()), "html", null, true);
                echo "</a></td>
                <td>";
                // line 20
                echo twig_escape_filter($this->env, $this->getAttribute($context["rol"], "nombre", array()), "html", null, true);
                echo "</td>
                <td>";
                // line 21
                if ($this->getAttribute($context["rol"], "baja", array())) {
                    echo "Yes";
                } else {
                    echo "No";
                }
                echo "</td>
                <td>

                            <a href=\"";
                // line 24
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_rol_show", array("id" => $this->getAttribute($context["rol"], "id", array()))), "html", null, true);
                echo "\">show</a>
                </td>
                <td>
                            <a href=\"";
                // line 27
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_rol_edit", array("id" => $this->getAttribute($context["rol"], "id", array()))), "html", null, true);
                echo "\">edit</a>

                </td>
            </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['rol'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 32
            echo "        </tbody>
    </table>
    ";
        } else {
            // line 35
            echo "        <h2>No hay roles incorporados</h2>
    ";
        }
        // line 37
        echo "

            <a href=\"";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_rol_new");
        echo "\">Create a new rol</a>

";
        
        $__internal_1da857f44271fcf220d9c95a43a1eaa0094f34cf79ce5542170cf9a53ef49110->leave($__internal_1da857f44271fcf220d9c95a43a1eaa0094f34cf79ce5542170cf9a53ef49110_prof);

    }

    public function getTemplateName()
    {
        return "Admin/partials/rol/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 39,  111 => 37,  107 => 35,  102 => 32,  91 => 27,  85 => 24,  75 => 21,  71 => 20,  65 => 19,  62 => 18,  58 => 17,  45 => 6,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Admin/layout.html.twig' %}

{% block main %}
    <h1>Roles lista</h1>
    {% if rols is not empty %}
    <table class=\"table table-striped table-hover\">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nombre</th>
                <th>Baja</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        {% for rol in rols %}
            <tr>
                <td><a href=\"{{ path('admin_rol_show', { 'id': rol.id }) }}\">{{ rol.id }}</a></td>
                <td>{{ rol.nombre }}</td>
                <td>{% if rol.baja %}Yes{% else %}No{% endif %}</td>
                <td>

                            <a href=\"{{ path('admin_rol_show', { 'id': rol.id }) }}\">show</a>
                </td>
                <td>
                            <a href=\"{{ path('admin_rol_edit', { 'id': rol.id }) }}\">edit</a>

                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    {% else %}
        <h2>No hay roles incorporados</h2>
    {% endif %}


            <a href=\"{{ path('admin_rol_new') }}\">Create a new rol</a>

{% endblock %}
", "Admin/partials/rol/index.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/partials/rol/index.html.twig");
    }
}
