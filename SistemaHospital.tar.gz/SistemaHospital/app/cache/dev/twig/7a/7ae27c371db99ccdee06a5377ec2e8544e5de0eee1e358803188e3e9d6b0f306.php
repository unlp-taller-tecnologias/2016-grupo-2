<?php

/* base.html.twig */
class __TwigTemplate_1744bc1509247b993057fd38cde81e7b6f88e0a34fd80ff030b00372429ebb7d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'header_navigation_links' => array($this, 'block_header_navigation_links'),
            'body' => array($this, 'block_body'),
            'sidebar' => array($this, 'block_sidebar'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c9de2b677b1ab680b0167293cac6cfaa3a73121efb8e6273dd8682ceba91d01a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c9de2b677b1ab680b0167293cac6cfaa3a73121efb8e6273dd8682ceba91d01a->enter($__internal_c9de2b677b1ab680b0167293cac6cfaa3a73121efb8e6273dd8682ceba91d01a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "
<!DOCTYPE html>
<html lang=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()), "html", null, true);
        echo "\">
<head>
    <meta charset=\"UTF-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 79
        echo "
<div class=\"container body-container\">
    ";
        // line 81
        $this->displayBlock('body', $context, $blocks);
        // line 101
        echo "</div>

";
        // line 103
        $this->displayBlock('footer', $context, $blocks);
        // line 114
        echo "
";
        // line 115
        $this->displayBlock('javascripts', $context, $blocks);
        // line 124
        echo "

</body>
</html>
";
        
        $__internal_c9de2b677b1ab680b0167293cac6cfaa3a73121efb8e6273dd8682ceba91d01a->leave($__internal_c9de2b677b1ab680b0167293cac6cfaa3a73121efb8e6273dd8682ceba91d01a_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_c26d44acf856b8c6b9c2374c18665c390bf4ff63c0ada6f52abd0bc0d0b5d4da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c26d44acf856b8c6b9c2374c18665c390bf4ff63c0ada6f52abd0bc0d0b5d4da->enter($__internal_c26d44acf856b8c6b9c2374c18665c390bf4ff63c0ada6f52abd0bc0d0b5d4da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "base.html.twig"));

        echo "HospitalRossi";
        
        $__internal_c26d44acf856b8c6b9c2374c18665c390bf4ff63c0ada6f52abd0bc0d0b5d4da->leave($__internal_c26d44acf856b8c6b9c2374c18665c390bf4ff63c0ada6f52abd0bc0d0b5d4da_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_7b68fbde0f7a49592988f48f4d76fab38cae0c0e9e40d7686bba0e91082e7d3f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7b68fbde0f7a49592988f48f4d76fab38cae0c0e9e40d7686bba0e91082e7d3f->enter($__internal_7b68fbde0f7a49592988f48f4d76fab38cae0c0e9e40d7686bba0e91082e7d3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "base.html.twig"));

        // line 9
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-flatly-3.3.7.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/font-awesome-4.6.3.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/font-lato.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/highlight-solarized-light.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/main.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_7b68fbde0f7a49592988f48f4d76fab38cae0c0e9e40d7686bba0e91082e7d3f->leave($__internal_7b68fbde0f7a49592988f48f4d76fab38cae0c0e9e40d7686bba0e91082e7d3f_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_3b26dff8ef76c58156debbff06bfffa55cb2be289637eed599f9ec0d4e1daa9b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3b26dff8ef76c58156debbff06bfffa55cb2be289637eed599f9ec0d4e1daa9b->enter($__internal_3b26dff8ef76c58156debbff06bfffa55cb2be289637eed599f9ec0d4e1daa9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "base.html.twig"));

        
        $__internal_3b26dff8ef76c58156debbff06bfffa55cb2be289637eed599f9ec0d4e1daa9b->leave($__internal_3b26dff8ef76c58156debbff06bfffa55cb2be289637eed599f9ec0d4e1daa9b_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_dcbc4b65446f79cbb03d30b655fe4dabfb9793cf4c42605f9780e29ee92e0921 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dcbc4b65446f79cbb03d30b655fe4dabfb9793cf4c42605f9780e29ee92e0921->enter($__internal_dcbc4b65446f79cbb03d30b655fe4dabfb9793cf4c42605f9780e29ee92e0921_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "base.html.twig"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a class=\"navbar-brand\" href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">
                        Hospital Rossi
                    </a>

                    <button type=\"button\" class=\"navbar-toggle\"
                            data-toggle=\"collapse\"
                            data-target=\".navbar-collapse\">
                        <span class=\"sr-only\">menu_desplegable</span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>
                <div class=\"navbar-collapse collapse\">
                    <ul class=\"nav navbar-nav navbar-right\">
                        ";
        // line 41
        $this->displayBlock('header_navigation_links', $context, $blocks);
        // line 73
        echo "                    </ul>
                </div>
            </div>
        </div>
    </header>
";
        
        $__internal_dcbc4b65446f79cbb03d30b655fe4dabfb9793cf4c42605f9780e29ee92e0921->leave($__internal_dcbc4b65446f79cbb03d30b655fe4dabfb9793cf4c42605f9780e29ee92e0921_prof);

    }

    // line 41
    public function block_header_navigation_links($context, array $blocks = array())
    {
        $__internal_80215a120f7a752fc336f5dd5b94e267c75315f6f759a3c69fb7b5d5fa6233ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80215a120f7a752fc336f5dd5b94e267c75315f6f759a3c69fb7b5d5fa6233ba->enter($__internal_80215a120f7a752fc336f5dd5b94e267c75315f6f759a3c69fb7b5d5fa6233ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "base.html.twig"));

        // line 42
        echo "                            <li>
                                <a href=\"";
        // line 43
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("reserva_index");
        echo "\">
                                    <i class=\"fa fa-plus-square\" aria-hidden=\"true\"></i> Reservas
                                </a>
                            </li>
                            <li>
                                <a href=\"#";
        // line 48
        echo "\">
                                    <i class=\"fa fa-stethoscope \" aria-hidden=\"true\"></i> Operaciones
                                </a>
                            </li>

                            ";
        // line 54
        echo "                            <li>
                                <a href=\"";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("personal_index");
        echo "\">
                                    <i class=\"fa fa-wrench\" aria-hidden=\"true\"></i> Configuracion
                                </a>
                            </li>
                            ";
        // line 59
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER")) {
            // line 60
            echo "                                <li>
                                    <a href=\"";
            // line 61
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\">
                                        <i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Cerrar sesion
                                    </a>
                                </li>
                            ";
        }
        // line 66
        echo "                            <form class=\"navbar-form navbar-left\" role=\"search\">
                                <div class=\"form-group\">
                                    <input type=\"text\" class=\"form-control\" placeholder=\"Search\">
                                </div>
                                <button type=\"submit\" class=\"btn btn-default\">Buscar</button>
                            </form>
                        ";
        
        $__internal_80215a120f7a752fc336f5dd5b94e267c75315f6f759a3c69fb7b5d5fa6233ba->leave($__internal_80215a120f7a752fc336f5dd5b94e267c75315f6f759a3c69fb7b5d5fa6233ba_prof);

    }

    // line 81
    public function block_body($context, array $blocks = array())
    {
        $__internal_2dcba76632ff8019f79470dd2716d69efc163cdd27724856c483ad194735de04 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2dcba76632ff8019f79470dd2716d69efc163cdd27724856c483ad194735de04->enter($__internal_2dcba76632ff8019f79470dd2716d69efc163cdd27724856c483ad194735de04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "base.html.twig"));

        // line 82
        echo "        <div class=\"row\">

            <div id=\"sidebar\" class=\"col-sm-3\">
                ";
        // line 85
        $this->displayBlock('sidebar', $context, $blocks);
        // line 88
        echo "            </div>


            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 92
        echo twig_include($this->env, $context, "default/_flash_messages.html.twig");
        echo "

                ";
        // line 94
        $this->displayBlock('main', $context, $blocks);
        // line 97
        echo "            </div>

        </div>
    ";
        
        $__internal_2dcba76632ff8019f79470dd2716d69efc163cdd27724856c483ad194735de04->leave($__internal_2dcba76632ff8019f79470dd2716d69efc163cdd27724856c483ad194735de04_prof);

    }

    // line 85
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_d5ff74c2124ac107a8ea119f0fd0d347994afddc2319c220c5f171e238f3990c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d5ff74c2124ac107a8ea119f0fd0d347994afddc2319c220c5f171e238f3990c->enter($__internal_d5ff74c2124ac107a8ea119f0fd0d347994afddc2319c220c5f171e238f3990c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "base.html.twig"));

        // line 86
        echo "                    ";
        // line 87
        echo "                ";
        
        $__internal_d5ff74c2124ac107a8ea119f0fd0d347994afddc2319c220c5f171e238f3990c->leave($__internal_d5ff74c2124ac107a8ea119f0fd0d347994afddc2319c220c5f171e238f3990c_prof);

    }

    // line 94
    public function block_main($context, array $blocks = array())
    {
        $__internal_1c6aa57744e4a18cc02b4df7ad4c54dae0031ae57771d45e714e20a775b6d3bf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1c6aa57744e4a18cc02b4df7ad4c54dae0031ae57771d45e714e20a775b6d3bf->enter($__internal_1c6aa57744e4a18cc02b4df7ad4c54dae0031ae57771d45e714e20a775b6d3bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "base.html.twig"));

        // line 95
        echo "                   ";
        // line 96
        echo "                ";
        
        $__internal_1c6aa57744e4a18cc02b4df7ad4c54dae0031ae57771d45e714e20a775b6d3bf->leave($__internal_1c6aa57744e4a18cc02b4df7ad4c54dae0031ae57771d45e714e20a775b6d3bf_prof);

    }

    // line 103
    public function block_footer($context, array $blocks = array())
    {
        $__internal_ae8eb6bc4e60d999273b11b46143ee0160939c683b837dda30688dd180e4520f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ae8eb6bc4e60d999273b11b46143ee0160939c683b837dda30688dd180e4520f->enter($__internal_ae8eb6bc4e60d999273b11b46143ee0160939c683b837dda30688dd180e4520f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "base.html.twig"));

        // line 104
        echo "    <footer>
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"footer-copyright\" class=\"col-md-6\">
                    <p>&copy; ";
        // line 108
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " - Proyecto - UNLP|Facultad Informatica</p>
                </div>
            </div>
        </div>
    </footer>
";
        
        $__internal_ae8eb6bc4e60d999273b11b46143ee0160939c683b837dda30688dd180e4520f->leave($__internal_ae8eb6bc4e60d999273b11b46143ee0160939c683b837dda30688dd180e4520f_prof);

    }

    // line 115
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_318fb1fdcccbdcb0dee30155f6911cdaaed88bdfb471a1d38a39ff781911346f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_318fb1fdcccbdcb0dee30155f6911cdaaed88bdfb471a1d38a39ff781911346f->enter($__internal_318fb1fdcccbdcb0dee30155f6911cdaaed88bdfb471a1d38a39ff781911346f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "base.html.twig"));

        // line 116
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 117
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 118
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-3.3.7.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 119
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/highlight.pack.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 121
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/main.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 122
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/genericos.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_318fb1fdcccbdcb0dee30155f6911cdaaed88bdfb471a1d38a39ff781911346f->leave($__internal_318fb1fdcccbdcb0dee30155f6911cdaaed88bdfb471a1d38a39ff781911346f_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  376 => 122,  372 => 121,  368 => 120,  364 => 119,  360 => 118,  356 => 117,  351 => 116,  345 => 115,  332 => 108,  326 => 104,  320 => 103,  313 => 96,  311 => 95,  305 => 94,  298 => 87,  296 => 86,  290 => 85,  280 => 97,  278 => 94,  273 => 92,  267 => 88,  265 => 85,  260 => 82,  254 => 81,  241 => 66,  233 => 61,  230 => 60,  228 => 59,  221 => 55,  218 => 54,  211 => 48,  203 => 43,  200 => 42,  194 => 41,  182 => 73,  180 => 41,  162 => 26,  156 => 22,  150 => 21,  139 => 19,  130 => 14,  126 => 13,  122 => 12,  118 => 11,  114 => 10,  109 => 9,  103 => 8,  91 => 7,  80 => 124,  78 => 115,  75 => 114,  73 => 103,  69 => 101,  67 => 81,  63 => 79,  61 => 21,  56 => 19,  49 => 16,  47 => 8,  43 => 7,  36 => 3,  32 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
<!DOCTYPE html>
<html lang=\"{{ app.request.locale }}\">
<head>
    <meta charset=\"UTF-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}HospitalRossi{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-flatly-3.3.7.min.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/font-awesome-4.6.3.min.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/font-lato.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/highlight-solarized-light.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/main.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a class=\"navbar-brand\" href=\"{{ path('homepage') }}\">
                        Hospital Rossi
                    </a>

                    <button type=\"button\" class=\"navbar-toggle\"
                            data-toggle=\"collapse\"
                            data-target=\".navbar-collapse\">
                        <span class=\"sr-only\">menu_desplegable</span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>
                <div class=\"navbar-collapse collapse\">
                    <ul class=\"nav navbar-nav navbar-right\">
                        {% block header_navigation_links %}
                            <li>
                                <a href=\"{{ path('reserva_index') }}\">
                                    <i class=\"fa fa-plus-square\" aria-hidden=\"true\"></i> Reservas
                                </a>
                            </li>
                            <li>
                                <a href=\"#{#{{ path('operacion_index') }}#}\">
                                    <i class=\"fa fa-stethoscope \" aria-hidden=\"true\"></i> Operaciones
                                </a>
                            </li>

                            {#ESto es lo que va a ver el admin#}
                            <li>
                                <a href=\"{{ path('personal_index') }}\">
                                    <i class=\"fa fa-wrench\" aria-hidden=\"true\"></i> Configuracion
                                </a>
                            </li>
                            {% if is_granted('ROLE_USER') %}
                                <li>
                                    <a href=\"{{ path('fos_user_security_logout') }}\">
                                        <i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Cerrar sesion
                                    </a>
                                </li>
                            {% endif %}
                            <form class=\"navbar-form navbar-left\" role=\"search\">
                                <div class=\"form-group\">
                                    <input type=\"text\" class=\"form-control\" placeholder=\"Search\">
                                </div>
                                <button type=\"submit\" class=\"btn btn-default\">Buscar</button>
                            </form>
                        {% endblock %}
                    </ul>
                </div>
            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">

            <div id=\"sidebar\" class=\"col-sm-3\">
                {% block sidebar %}
                    {#aca va el sidebar de operaciones o reservas o configuracoines... serian las opciones#}
                {% endblock %}
            </div>


            <div id=\"main\" class=\"col-sm-9\">
                {{ include('default/_flash_messages.html.twig') }}

                {% block main %}
                   {#Aca va el el contenido mas importante por lo general van a ser las tablas y las estadisticas#}
                {% endblock %}
            </div>

        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"footer-copyright\" class=\"col-md-6\">
                    <p>&copy; {{ 'now'|date('Y') }} - Proyecto - UNLP|Facultad Informatica</p>
                </div>
            </div>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-3.3.7.min.js') }}\"></script>
    <script src=\"{{ asset('js/highlight.pack.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
    <script src=\"{{ asset('js/main.js') }}\"></script>
    <script src=\"{{ asset('js/genericos.js') }}\"></script>
{% endblock %}


</body>
</html>
", "base.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/base.html.twig");
    }
}
