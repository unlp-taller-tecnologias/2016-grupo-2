<?php

/* Admin/partials/estado/index.html.twig */
class __TwigTemplate_711dc86b427dabd67e60709c0f5e6400751a4160f1b73f73e5de7ac27771ea0d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Admin/layout.html.twig", "Admin/partials/estado/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "Admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a46ea939867bb61c595713afaee4d6e75b2f7eb773452b23617b948eec00cdbd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a46ea939867bb61c595713afaee4d6e75b2f7eb773452b23617b948eec00cdbd->enter($__internal_a46ea939867bb61c595713afaee4d6e75b2f7eb773452b23617b948eec00cdbd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/partials/estado/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a46ea939867bb61c595713afaee4d6e75b2f7eb773452b23617b948eec00cdbd->leave($__internal_a46ea939867bb61c595713afaee4d6e75b2f7eb773452b23617b948eec00cdbd_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_2267f162fee531f10d2a62b960df9e1654a7bdb20caaa731af5396d5d8e066d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2267f162fee531f10d2a62b960df9e1654a7bdb20caaa731af5396d5d8e066d0->enter($__internal_2267f162fee531f10d2a62b960df9e1654a7bdb20caaa731af5396d5d8e066d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/partials/estado/index.html.twig"));

        // line 4
        echo "    <h1>Estados list</h1>

";
        // line 6
        if ( !twig_test_empty((isset($context["estados"]) ? $context["estados"] : $this->getContext($context, "estados")))) {
            // line 7
            echo "<table class=\"table table-striped table-hover\">
        <thead>
            <tr>
                <th>Id</th>
                <th>Tipo</th>
                <th>Descripcion</th>
                <th>Baja</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        ";
            // line 19
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["estados"]) ? $context["estados"] : $this->getContext($context, "estados")));
            foreach ($context['_seq'] as $context["_key"] => $context["estado"]) {
                // line 20
                echo "            <tr>
                <td><a href=\"";
                // line 21
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_estado_show", array("id" => $this->getAttribute($context["estado"], "id", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["estado"], "id", array()), "html", null, true);
                echo "</a></td>
                <td>";
                // line 22
                echo twig_escape_filter($this->env, $this->getAttribute($context["estado"], "tipo", array()), "html", null, true);
                echo "</td>
                <td>";
                // line 23
                echo twig_escape_filter($this->env, $this->getAttribute($context["estado"], "descripcion", array()), "html", null, true);
                echo "</td>
                <td>";
                // line 24
                if ($this->getAttribute($context["estado"], "baja", array())) {
                    echo "Yes";
                } else {
                    echo "No";
                }
                echo "</td>
                <td>
                    <a href=\"";
                // line 26
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_estado_show", array("id" => $this->getAttribute($context["estado"], "id", array()))), "html", null, true);
                echo "\">show</a>
                </td>
                <td>
                    <a href=\"";
                // line 29
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_estado_edit", array("id" => $this->getAttribute($context["estado"], "id", array()))), "html", null, true);
                echo "\">edit</a>
                </td>
            </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['estado'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 33
            echo "        </tbody>
    </table>
";
        } else {
            // line 36
            echo "    <h2>No hay estados incorporado</h2>
";
        }
        // line 38
        echo "    <a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_estado_new");
        echo "\">Create a new estado</a>
";
        
        $__internal_2267f162fee531f10d2a62b960df9e1654a7bdb20caaa731af5396d5d8e066d0->leave($__internal_2267f162fee531f10d2a62b960df9e1654a7bdb20caaa731af5396d5d8e066d0_prof);

    }

    public function getTemplateName()
    {
        return "Admin/partials/estado/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 38,  111 => 36,  106 => 33,  96 => 29,  90 => 26,  81 => 24,  77 => 23,  73 => 22,  67 => 21,  64 => 20,  60 => 19,  46 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Admin/layout.html.twig' %}

{% block main %}
    <h1>Estados list</h1>

{% if estados is not empty %}
<table class=\"table table-striped table-hover\">
        <thead>
            <tr>
                <th>Id</th>
                <th>Tipo</th>
                <th>Descripcion</th>
                <th>Baja</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        {% for estado in estados %}
            <tr>
                <td><a href=\"{{ path('admin_estado_show', { 'id': estado.id }) }}\">{{ estado.id }}</a></td>
                <td>{{ estado.tipo }}</td>
                <td>{{ estado.descripcion }}</td>
                <td>{% if estado.baja %}Yes{% else %}No{% endif %}</td>
                <td>
                    <a href=\"{{ path('admin_estado_show', { 'id': estado.id }) }}\">show</a>
                </td>
                <td>
                    <a href=\"{{ path('admin_estado_edit', { 'id': estado.id }) }}\">edit</a>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
{% else %}
    <h2>No hay estados incorporado</h2>
{% endif %}
    <a href=\"{{ path('admin_estado_new') }}\">Create a new estado</a>
{% endblock %}
", "Admin/partials/estado/index.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/partials/estado/index.html.twig");
    }
}
