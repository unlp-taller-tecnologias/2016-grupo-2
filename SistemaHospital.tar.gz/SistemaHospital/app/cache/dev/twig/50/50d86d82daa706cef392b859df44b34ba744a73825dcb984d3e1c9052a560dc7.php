<?php

/* reservas/index.html.twig */
class __TwigTemplate_0ecdd73fe2d8c03f6bd4048cae44061fa22c396a9c59f1a9d99d78ef10e8991a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "reservas/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_48bac0dd0074a33b164435613822082755d6e7f6413ac3558e480810ab80e8b2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48bac0dd0074a33b164435613822082755d6e7f6413ac3558e480810ab80e8b2->enter($__internal_48bac0dd0074a33b164435613822082755d6e7f6413ac3558e480810ab80e8b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "reservas/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_48bac0dd0074a33b164435613822082755d6e7f6413ac3558e480810ab80e8b2->leave($__internal_48bac0dd0074a33b164435613822082755d6e7f6413ac3558e480810ab80e8b2_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_904a0471cac8c299c0092a1c131842a939343c1ac6fd998e2e54587c6ce559ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_904a0471cac8c299c0092a1c131842a939343c1ac6fd998e2e54587c6ce559ff->enter($__internal_904a0471cac8c299c0092a1c131842a939343c1ac6fd998e2e54587c6ce559ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "reservas/index.html.twig"));

        // line 4
        echo "    <h1>esto es la primera prueba de linkeo</h1>
";
        
        $__internal_904a0471cac8c299c0092a1c131842a939343c1ac6fd998e2e54587c6ce559ff->leave($__internal_904a0471cac8c299c0092a1c131842a939343c1ac6fd998e2e54587c6ce559ff_prof);

    }

    public function getTemplateName()
    {
        return "reservas/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block main %}
    <h1>esto es la primera prueba de linkeo</h1>
{% endblock %}


", "reservas/index.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/reservas/index.html.twig");
    }
}
