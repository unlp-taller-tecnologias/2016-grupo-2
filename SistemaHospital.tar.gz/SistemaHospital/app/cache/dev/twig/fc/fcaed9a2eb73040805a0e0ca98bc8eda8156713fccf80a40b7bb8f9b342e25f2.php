<?php

/* Admin/partials/user/show.html.twig */
class __TwigTemplate_8b54c63d3f20ba0bd3ab14a136424242856f02ff7e522ecb447c4284bfe96763 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Admin/layout.html.twig", "Admin/partials/user/show.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "Admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f10f2f428fbd9c283f634cf2f72a7933a5b99cf546b45c4f3daac6085a3fa8ac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f10f2f428fbd9c283f634cf2f72a7933a5b99cf546b45c4f3daac6085a3fa8ac->enter($__internal_f10f2f428fbd9c283f634cf2f72a7933a5b99cf546b45c4f3daac6085a3fa8ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/partials/user/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f10f2f428fbd9c283f634cf2f72a7933a5b99cf546b45c4f3daac6085a3fa8ac->leave($__internal_f10f2f428fbd9c283f634cf2f72a7933a5b99cf546b45c4f3daac6085a3fa8ac_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_697fd4f52b8210954080d4e84f42f437cfbee1685af9fefdcb68ebc0c79b07b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_697fd4f52b8210954080d4e84f42f437cfbee1685af9fefdcb68ebc0c79b07b6->enter($__internal_697fd4f52b8210954080d4e84f42f437cfbee1685af9fefdcb68ebc0c79b07b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/partials/user/show.html.twig"));

        // line 4
        echo "    <h1>User</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            <a href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_edit", array("id" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "id", array()))), "html", null, true);
        echo "\">Edit</a>
        </li>
        <li>
            ";
        // line 23
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 25
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_697fd4f52b8210954080d4e84f42f437cfbee1685af9fefdcb68ebc0c79b07b6->leave($__internal_697fd4f52b8210954080d4e84f42f437cfbee1685af9fefdcb68ebc0c79b07b6_prof);

    }

    public function getTemplateName()
    {
        return "Admin/partials/user/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 25,  70 => 23,  64 => 20,  58 => 17,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Admin/layout.html.twig' %}

{% block main %}
    <h1>User</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ user.id }}</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('user_index') }}\">Back to the list</a>
        </li>
        <li>
            <a href=\"{{ path('user_edit', { 'id': user.id }) }}\">Edit</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", "Admin/partials/user/show.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/partials/user/show.html.twig");
    }
}
