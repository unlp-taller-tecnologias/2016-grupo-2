<?php

/* Admin/partials/rol/new.html.twig */
class __TwigTemplate_ce90e6daf083ad87fe87180ba35c713614e54fbae4ab1350671bb3d5420be7e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Admin/layout.html.twig", "Admin/partials/rol/new.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "Admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_620d4e4b8cc53e1f10fc1f3e4233ef3578d78a67f91051382dcbfb966c113096 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_620d4e4b8cc53e1f10fc1f3e4233ef3578d78a67f91051382dcbfb966c113096->enter($__internal_620d4e4b8cc53e1f10fc1f3e4233ef3578d78a67f91051382dcbfb966c113096_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/partials/rol/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_620d4e4b8cc53e1f10fc1f3e4233ef3578d78a67f91051382dcbfb966c113096->leave($__internal_620d4e4b8cc53e1f10fc1f3e4233ef3578d78a67f91051382dcbfb966c113096_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_d1922e45105fa753c55a6f9d4522f558ae88295058c5573cdd08cb695e18ed51 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d1922e45105fa753c55a6f9d4522f558ae88295058c5573cdd08cb695e18ed51->enter($__internal_d1922e45105fa753c55a6f9d4522f558ae88295058c5573cdd08cb695e18ed51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/partials/rol/new.html.twig"));

        // line 4
        echo "    <h1>Rol creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "


            <a href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_rol_index");
        echo "\">Back to the list</a>

";
        
        $__internal_d1922e45105fa753c55a6f9d4522f558ae88295058c5573cdd08cb695e18ed51->leave($__internal_d1922e45105fa753c55a6f9d4522f558ae88295058c5573cdd08cb695e18ed51_prof);

    }

    public function getTemplateName()
    {
        return "Admin/partials/rol/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 12,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Admin/layout.html.twig' %}

{% block main %}
    <h1>Rol creation</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input type=\"submit\" value=\"Create\" />
    {{ form_end(form) }}


            <a href=\"{{ path('admin_rol_index') }}\">Back to the list</a>

{% endblock %}
", "Admin/partials/rol/new.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/partials/rol/new.html.twig");
    }
}
