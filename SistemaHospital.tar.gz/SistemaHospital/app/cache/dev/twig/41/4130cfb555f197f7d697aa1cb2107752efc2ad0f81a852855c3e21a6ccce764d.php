<?php

/* Admin/partials/quirofano/new.html.twig */
class __TwigTemplate_618cffd48d1881be9c1b529cd2d7da209430feecd24f776232276717b0b1e24c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Admin/layout.html.twig", "Admin/partials/quirofano/new.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "Admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7bda5012d8ccd101bd93ce4fa9b3999e03e0ddc0e68b7e0999273799a53173b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7bda5012d8ccd101bd93ce4fa9b3999e03e0ddc0e68b7e0999273799a53173b1->enter($__internal_7bda5012d8ccd101bd93ce4fa9b3999e03e0ddc0e68b7e0999273799a53173b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/partials/quirofano/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7bda5012d8ccd101bd93ce4fa9b3999e03e0ddc0e68b7e0999273799a53173b1->leave($__internal_7bda5012d8ccd101bd93ce4fa9b3999e03e0ddc0e68b7e0999273799a53173b1_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_d72e02a30fcd6585a7d4bf61d8bbde90dbc5ec29c28f0576a3d115b7a5c203be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d72e02a30fcd6585a7d4bf61d8bbde90dbc5ec29c28f0576a3d115b7a5c203be->enter($__internal_d72e02a30fcd6585a7d4bf61d8bbde90dbc5ec29c28f0576a3d115b7a5c203be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/partials/quirofano/new.html.twig"));

        // line 4
        echo "    <h1>Quirofano creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_quirofano_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_d72e02a30fcd6585a7d4bf61d8bbde90dbc5ec29c28f0576a3d115b7a5c203be->leave($__internal_d72e02a30fcd6585a7d4bf61d8bbde90dbc5ec29c28f0576a3d115b7a5c203be_prof);

    }

    public function getTemplateName()
    {
        return "Admin/partials/quirofano/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Admin/layout.html.twig' %}

{% block main %}
    <h1>Quirofano creation</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input type=\"submit\" value=\"Create\" />
    {{ form_end(form) }}

    <ul>
        <li>
            <a href=\"{{ path('admin_quirofano_index') }}\">Back to the list</a>
        </li>
    </ul>
{% endblock %}
", "Admin/partials/quirofano/new.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/partials/quirofano/new.html.twig");
    }
}
