<?php

/* Admin/partials/asa/index.html.twig */
class __TwigTemplate_4422cea20ac37835660c361492c91e60304e22f8e4846f8cdc90fba08385b279 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Admin/layout.html.twig", "Admin/partials/asa/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "Admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_31f869bf8e7c2e8f5f08037fd02b20205299f5a2b2364b226b2948b8ffbcc5c4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31f869bf8e7c2e8f5f08037fd02b20205299f5a2b2364b226b2948b8ffbcc5c4->enter($__internal_31f869bf8e7c2e8f5f08037fd02b20205299f5a2b2364b226b2948b8ffbcc5c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/partials/asa/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_31f869bf8e7c2e8f5f08037fd02b20205299f5a2b2364b226b2948b8ffbcc5c4->leave($__internal_31f869bf8e7c2e8f5f08037fd02b20205299f5a2b2364b226b2948b8ffbcc5c4_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_31356f92ffd98464fc11c2bd07a01c55336ae6d85c4a2ef38abfc37081ce84a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31356f92ffd98464fc11c2bd07a01c55336ae6d85c4a2ef38abfc37081ce84a5->enter($__internal_31356f92ffd98464fc11c2bd07a01c55336ae6d85c4a2ef38abfc37081ce84a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/partials/asa/index.html.twig"));

        // line 4
        echo "    <h1>Asas list</h1>


";
        // line 7
        if ( !twig_test_empty((isset($context["asas"]) ? $context["asas"] : $this->getContext($context, "asas")))) {
            // line 8
            echo "<table class=\"table table-striped table-hover\">
        <thead>
            <tr>
                <th>Id</th>
                <th>Grado</th>
                <th>Descripcion</th>
                <th>Baja</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        ";
            // line 20
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["asas"]) ? $context["asas"] : $this->getContext($context, "asas")));
            foreach ($context['_seq'] as $context["_key"] => $context["asa"]) {
                // line 21
                echo "            <tr>
                <td><a href=\"";
                // line 22
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_asa_show", array("id" => $this->getAttribute($context["asa"], "id", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["asa"], "id", array()), "html", null, true);
                echo "</a></td>
                <td>";
                // line 23
                echo twig_escape_filter($this->env, $this->getAttribute($context["asa"], "grado", array()), "html", null, true);
                echo "</td>
                <td>";
                // line 24
                echo twig_escape_filter($this->env, $this->getAttribute($context["asa"], "descripcion", array()), "html", null, true);
                echo "</td>
                <td>";
                // line 25
                if ($this->getAttribute($context["asa"], "baja", array())) {
                    echo "Yes";
                } else {
                    echo "No";
                }
                echo "</td>
                <td>
                    <a href=\"";
                // line 27
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_asa_show", array("id" => $this->getAttribute($context["asa"], "id", array()))), "html", null, true);
                echo "\">show</a>
                </td>
                <td>
                    <a href=\"";
                // line 30
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_asa_edit", array("id" => $this->getAttribute($context["asa"], "id", array()))), "html", null, true);
                echo "\">edit</a>
                </td>
            </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['asa'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 34
            echo "        </tbody>
    </table>
";
        } else {
            // line 37
            echo "    <h2>No hay Asa incorporadas</h2>
";
        }
        // line 39
        echo "
  <a href=\"";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_asa_new");
        echo "\">Create a new asa</a>

";
        
        $__internal_31356f92ffd98464fc11c2bd07a01c55336ae6d85c4a2ef38abfc37081ce84a5->leave($__internal_31356f92ffd98464fc11c2bd07a01c55336ae6d85c4a2ef38abfc37081ce84a5_prof);

    }

    public function getTemplateName()
    {
        return "Admin/partials/asa/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 40,  116 => 39,  112 => 37,  107 => 34,  97 => 30,  91 => 27,  82 => 25,  78 => 24,  74 => 23,  68 => 22,  65 => 21,  61 => 20,  47 => 8,  45 => 7,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Admin/layout.html.twig' %}

{% block main %}
    <h1>Asas list</h1>


{% if asas is not empty %}
<table class=\"table table-striped table-hover\">
        <thead>
            <tr>
                <th>Id</th>
                <th>Grado</th>
                <th>Descripcion</th>
                <th>Baja</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        {% for asa in asas %}
            <tr>
                <td><a href=\"{{ path('admin_asa_show', { 'id': asa.id }) }}\">{{ asa.id }}</a></td>
                <td>{{ asa.grado }}</td>
                <td>{{ asa.descripcion }}</td>
                <td>{% if asa.baja %}Yes{% else %}No{% endif %}</td>
                <td>
                    <a href=\"{{ path('admin_asa_show', { 'id': asa.id }) }}\">show</a>
                </td>
                <td>
                    <a href=\"{{ path('admin_asa_edit', { 'id': asa.id }) }}\">edit</a>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
{% else %}
    <h2>No hay Asa incorporadas</h2>
{% endif %}

  <a href=\"{{ path('admin_asa_new') }}\">Create a new asa</a>

{% endblock %}
", "Admin/partials/asa/index.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/partials/asa/index.html.twig");
    }
}
