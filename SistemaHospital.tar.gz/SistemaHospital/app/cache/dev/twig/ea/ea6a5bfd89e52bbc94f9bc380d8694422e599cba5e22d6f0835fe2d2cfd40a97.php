<?php

/* Admin/partials/personal/index.html.twig */
class __TwigTemplate_4faf3fc40d102ed168d4eee49ec829925a20995e5dfcd72734aca4afaddbbdd8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Admin/layout.html.twig", "Admin/partials/personal/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "Admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_52cabcf0a2593c65f977ba9357bc665f15794e408272c3f4474b0c88fe69f064 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_52cabcf0a2593c65f977ba9357bc665f15794e408272c3f4474b0c88fe69f064->enter($__internal_52cabcf0a2593c65f977ba9357bc665f15794e408272c3f4474b0c88fe69f064_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/partials/personal/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_52cabcf0a2593c65f977ba9357bc665f15794e408272c3f4474b0c88fe69f064->leave($__internal_52cabcf0a2593c65f977ba9357bc665f15794e408272c3f4474b0c88fe69f064_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_fe59089796a43afe111d80e3a8dbaa57ad82318cbf83f1350f46f0d90ef7311a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe59089796a43afe111d80e3a8dbaa57ad82318cbf83f1350f46f0d90ef7311a->enter($__internal_fe59089796a43afe111d80e3a8dbaa57ad82318cbf83f1350f46f0d90ef7311a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/partials/personal/index.html.twig"));

        // line 4
        echo "    <h1>Personals list</h1>
";
        // line 5
        if ( !twig_test_empty((isset($context["personals"]) ? $context["personals"] : $this->getContext($context, "personals")))) {
            // line 6
            echo "    <table class=\"table table-striped table-hover\">
        <thead>
            <tr>
                <th>Id</th>
                <th>Baja</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Genero</th>
                <th>Dni</th>
                <th>Edad</th>
                <th>Es administrador</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        ";
            // line 22
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["personals"]) ? $context["personals"] : $this->getContext($context, "personals")));
            foreach ($context['_seq'] as $context["_key"] => $context["personal"]) {
                // line 23
                echo "            <tr>
                <td><a href=\"";
                // line 24
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("personal_show", array("id" => $this->getAttribute($context["personal"], "id", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["personal"], "id", array()), "html", null, true);
                echo "</a></td>
                <td>";
                // line 25
                if ($this->getAttribute($context["personal"], "baja", array())) {
                    echo "Yes";
                } else {
                    echo "No";
                }
                echo "</td>
                <td>";
                // line 26
                echo twig_escape_filter($this->env, $this->getAttribute($context["personal"], "nombre", array()), "html", null, true);
                echo "</td>
                <td>";
                // line 27
                echo twig_escape_filter($this->env, $this->getAttribute($context["personal"], "apellido", array()), "html", null, true);
                echo "</td>
                <td>";
                // line 28
                echo twig_escape_filter($this->env, $this->getAttribute($context["personal"], "genero", array()), "html", null, true);
                echo "</td>
                <td>";
                // line 29
                echo twig_escape_filter($this->env, $this->getAttribute($context["personal"], "dni", array()), "html", null, true);
                echo "</td>
                <td>";
                // line 30
                echo twig_escape_filter($this->env, $this->getAttribute($context["personal"], "edad", array()), "html", null, true);
                echo "</td>

                <td>";
                // line 32
                if ( !twig_test_empty($this->getAttribute($context["personal"], "user", array()))) {
                    // line 33
                    echo "                        Si
                        ";
                } else {
                    // line 35
                    echo "                        No
                    ";
                }
                // line 37
                echo "                </td>
                <td>
                    <a href=\"";
                // line 39
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("personal_show", array("id" => $this->getAttribute($context["personal"], "id", array()))), "html", null, true);
                echo "\">show</a>
                </td>
                <td>
                    <a href=\"";
                // line 42
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("personal_edit", array("id" => $this->getAttribute($context["personal"], "id", array()))), "html", null, true);
                echo "\">edit</a>
                </td>
            </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['personal'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 46
            echo "        </tbody>
    </table>
    ";
        } else {
            // line 49
            echo "    <h2>No hay personal incorporado</h2>
    ";
        }
        // line 51
        echo "            <a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("personal_new");
        echo "\">Create a new personal</a>

";
        
        $__internal_fe59089796a43afe111d80e3a8dbaa57ad82318cbf83f1350f46f0d90ef7311a->leave($__internal_fe59089796a43afe111d80e3a8dbaa57ad82318cbf83f1350f46f0d90ef7311a_prof);

    }

    public function getTemplateName()
    {
        return "Admin/partials/personal/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 51,  140 => 49,  135 => 46,  125 => 42,  119 => 39,  115 => 37,  111 => 35,  107 => 33,  105 => 32,  100 => 30,  96 => 29,  92 => 28,  88 => 27,  84 => 26,  76 => 25,  70 => 24,  67 => 23,  63 => 22,  45 => 6,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Admin/layout.html.twig' %}

{% block main %}
    <h1>Personals list</h1>
{% if personals is not empty %}
    <table class=\"table table-striped table-hover\">
        <thead>
            <tr>
                <th>Id</th>
                <th>Baja</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Genero</th>
                <th>Dni</th>
                <th>Edad</th>
                <th>Es administrador</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        {% for personal in personals %}
            <tr>
                <td><a href=\"{{ path('personal_show', { 'id': personal.id }) }}\">{{ personal.id }}</a></td>
                <td>{% if personal.baja %}Yes{% else %}No{% endif %}</td>
                <td>{{ personal.nombre }}</td>
                <td>{{ personal.apellido }}</td>
                <td>{{ personal.genero }}</td>
                <td>{{ personal.dni }}</td>
                <td>{{ personal.edad }}</td>

                <td>{% if personal.user is not empty %}
                        Si
                        {% else %}
                        No
                    {% endif %}
                </td>
                <td>
                    <a href=\"{{ path('personal_show', { 'id': personal.id }) }}\">show</a>
                </td>
                <td>
                    <a href=\"{{ path('personal_edit', { 'id': personal.id }) }}\">edit</a>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    {% else %}
    <h2>No hay personal incorporado</h2>
    {% endif %}
            <a href=\"{{ path('personal_new') }}\">Create a new personal</a>

{% endblock %}
", "Admin/partials/personal/index.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/partials/personal/index.html.twig");
    }
}
