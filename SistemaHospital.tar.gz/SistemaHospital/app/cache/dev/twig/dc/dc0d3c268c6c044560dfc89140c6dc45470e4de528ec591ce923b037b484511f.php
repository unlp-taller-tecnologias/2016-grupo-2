<?php

/* Admin/partials/personal/show.html.twig */
class __TwigTemplate_6643d4adbecc351022910a4dd15830985ec405c5cb168ead9c5aecac16e2fda9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Admin/layout.html.twig", "Admin/partials/personal/show.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "Admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_adad01be1ede4a66e57420a61a4fda3365a653d1452788234d4b1e04f8d19a11 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_adad01be1ede4a66e57420a61a4fda3365a653d1452788234d4b1e04f8d19a11->enter($__internal_adad01be1ede4a66e57420a61a4fda3365a653d1452788234d4b1e04f8d19a11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/partials/personal/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_adad01be1ede4a66e57420a61a4fda3365a653d1452788234d4b1e04f8d19a11->leave($__internal_adad01be1ede4a66e57420a61a4fda3365a653d1452788234d4b1e04f8d19a11_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_40b6460e549e7a2153549dfc9c245f81bc9144a8f4296323e5e3af405744731e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_40b6460e549e7a2153549dfc9c245f81bc9144a8f4296323e5e3af405744731e->enter($__internal_40b6460e549e7a2153549dfc9c245f81bc9144a8f4296323e5e3af405744731e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/partials/personal/show.html.twig"));

        // line 4
        echo "    <h1>Personal</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Baja</th>
                <td>";
        // line 14
        if ($this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "baja", array())) {
            echo "Yes";
        } else {
            echo "No";
        }
        echo "</td>
            </tr>
            <tr>
                <th>Nombre</th>
                <td>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "nombre", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Apellido</th>
                <td>";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "apellido", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Genero</th>
                <td>";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "genero", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Dni</th>
                <td>";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "dni", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Edad</th>
                <td>";
        // line 34
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "edad", array()), "html", null, true);
        echo "</td>
            </tr>
            ";
        // line 36
        if ( !twig_test_empty($this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "user", array()))) {
            // line 37
            echo "                <tr>
                    <th>Nombre Usuario</th>
                    <td>";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "user", array()), "username", array()), "html", null, true);
            echo "</td>
                </tr>
            ";
        }
        // line 42
        echo "
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("personal_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            <a href=\"";
        // line 51
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("personal_edit", array("id" => $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "id", array()))), "html", null, true);
        echo "\">Edit</a>
        </li>
        <li>
            ";
        // line 54
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 56
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>

    ";
        // line 60
        if (twig_test_empty($this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "user", array()))) {
            // line 61
            echo "      <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_new", array("id_personal" => $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-primary\" >Create a new user</a>
    ";
        }
        
        $__internal_40b6460e549e7a2153549dfc9c245f81bc9144a8f4296323e5e3af405744731e->leave($__internal_40b6460e549e7a2153549dfc9c245f81bc9144a8f4296323e5e3af405744731e_prof);

    }

    public function getTemplateName()
    {
        return "Admin/partials/personal/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 61,  143 => 60,  136 => 56,  131 => 54,  125 => 51,  119 => 48,  111 => 42,  105 => 39,  101 => 37,  99 => 36,  94 => 34,  87 => 30,  80 => 26,  73 => 22,  66 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Admin/layout.html.twig' %}

{% block main %}
    <h1>Personal</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ personal.id }}</td>
            </tr>
            <tr>
                <th>Baja</th>
                <td>{% if personal.baja %}Yes{% else %}No{% endif %}</td>
            </tr>
            <tr>
                <th>Nombre</th>
                <td>{{ personal.nombre }}</td>
            </tr>
            <tr>
                <th>Apellido</th>
                <td>{{ personal.apellido }}</td>
            </tr>
            <tr>
                <th>Genero</th>
                <td>{{ personal.genero }}</td>
            </tr>
            <tr>
                <th>Dni</th>
                <td>{{ personal.dni }}</td>
            </tr>
            <tr>
                <th>Edad</th>
                <td>{{ personal.edad }}</td>
            </tr>
            {% if personal.user is not empty %}
                <tr>
                    <th>Nombre Usuario</th>
                    <td>{{ personal.user.username }}</td>
                </tr>
            {% endif %}

        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('personal_index') }}\">Back to the list</a>
        </li>
        <li>
            <a href=\"{{ path('personal_edit', { 'id': personal.id }) }}\">Edit</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>

    {% if personal.user is empty %}
      <a href=\"{{ path('user_new', { 'id_personal': personal.id }) }}\" class=\"btn btn-primary\" >Create a new user</a>
    {% endif %}
{% endblock %}
", "Admin/partials/personal/show.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/partials/personal/show.html.twig");
    }
}
