<?php

/* FOSUserBundle:Security:login.html.twig */
class __TwigTemplate_6a00dab9276892406a0eee69a468a162992f3405b64540c28991427eef6b1e9c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Security:login.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8b6a72a3cd65511e91291588e56a1c6a8a2153079bbe245ad088009265fa5dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8b6a72a3cd65511e91291588e56a1c6a8a2153079bbe245ad088009265fa5dc->enter($__internal_b8b6a72a3cd65511e91291588e56a1c6a8a2153079bbe245ad088009265fa5dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Security:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b8b6a72a3cd65511e91291588e56a1c6a8a2153079bbe245ad088009265fa5dc->leave($__internal_b8b6a72a3cd65511e91291588e56a1c6a8a2153079bbe245ad088009265fa5dc_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_160b09b67a6d496056e817008edee96e169d951225b9296da582eef21e5f6790 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_160b09b67a6d496056e817008edee96e169d951225b9296da582eef21e5f6790->enter($__internal_160b09b67a6d496056e817008edee96e169d951225b9296da582eef21e5f6790_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "FOSUserBundle:Security:login.html.twig"));

        // line 4
        echo "    ";
        echo twig_include($this->env, $context, "FOSUserBundle:Security:login_content.html.twig");
        echo "
";
        
        $__internal_160b09b67a6d496056e817008edee96e169d951225b9296da582eef21e5f6790->leave($__internal_160b09b67a6d496056e817008edee96e169d951225b9296da582eef21e5f6790_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Security:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
    {{ include('FOSUserBundle:Security:login_content.html.twig') }}
{% endblock fos_user_content %}
", "FOSUserBundle:Security:login.html.twig", "/var/www/html/taller/SistemaHospital/vendor/friendsofsymfony/user-bundle/Resources/views/Security/login.html.twig");
    }
}
