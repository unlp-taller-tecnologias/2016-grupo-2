<?php

/* Admin/layout.html.twig */
class __TwigTemplate_998d17e4598a0abbece00136b3156aade0dfa46f7fb257c11bf5c9d2f6cc4611 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "Admin/layout.html.twig", 1);
        $this->blocks = array(
            'sidebar' => array($this, 'block_sidebar'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3beb08946209ddf649689cb81a55acbcbe151082bcaad5ae77047e07c7ecc82f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3beb08946209ddf649689cb81a55acbcbe151082bcaad5ae77047e07c7ecc82f->enter($__internal_3beb08946209ddf649689cb81a55acbcbe151082bcaad5ae77047e07c7ecc82f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3beb08946209ddf649689cb81a55acbcbe151082bcaad5ae77047e07c7ecc82f->leave($__internal_3beb08946209ddf649689cb81a55acbcbe151082bcaad5ae77047e07c7ecc82f_prof);

    }

    // line 3
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_f86e029b222fcf20f3646d043233928a7846f671b799e6f84e929ef70b600162 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f86e029b222fcf20f3646d043233928a7846f671b799e6f84e929ef70b600162->enter($__internal_f86e029b222fcf20f3646d043233928a7846f671b799e6f84e929ef70b600162_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/layout.html.twig"));

        // line 4
        echo "     <ul class=\"nav nav-pills nav-stacked\">
         <li><a href=\"#\" id=\"btn-perfil\">Mi perfil</a></li>
         <li class=\"\" ><a href=\"";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("personal_index");
        echo "\" id=\"btn-personal\">Lista del Personal</a></li>
         <li class=\"\"><a href=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_index");
        echo "\" id=\"btn-usuarios\">Lista de Usuarios</a></li>
         <li class=\"dropdown\">
             <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\" >
                 Configuracion <span class=\"caret\"></span>
             </a>
             <ul class=\"dropdown-menu\">

                 <li><a href=\"";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_servicio_index");
        echo "\" id=\"btn-servicios\">Servicios</a></li>
                 <li><a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_rol_index");
        echo "\" id=\"btn-roles\">Roles</a></li>
                 <li><a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_anestesia_index");
        echo "\" id=\"btn-anestesias\">Tipos de Anestesias</a></li>
                 <li><a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_asa_index");
        echo "\" id=\"btn-asa\">ASA</a></li>
                 <li><a href=\"";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_quirofano_index");
        echo "\" id=\"btn-quirofano\">Quirófanos</a></li>
                 ";
        // line 19
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
            // line 20
            echo "                     ";
            // line 21
            echo "                     <li class=\"divider\"></li>
                     <li><a href=\"";
            // line 22
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_estado_index");
            echo "\">Estado Reserva</a></li>
                 ";
        }
        // line 24
        echo "             </ul>
         </li>
     </ul>
 ";
        
        $__internal_f86e029b222fcf20f3646d043233928a7846f671b799e6f84e929ef70b600162->leave($__internal_f86e029b222fcf20f3646d043233928a7846f671b799e6f84e929ef70b600162_prof);

    }

    // line 29
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_365aa409041773d167eec52bcbbe1427313e655eefc5f2cffe42590c5bb11f6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_365aa409041773d167eec52bcbbe1427313e655eefc5f2cffe42590c5bb11f6a->enter($__internal_365aa409041773d167eec52bcbbe1427313e655eefc5f2cffe42590c5bb11f6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/layout.html.twig"));

        // line 30
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script type=\"application/javascript\">
        \$(document).ready(function(){
            //no hya nada por ahora
        })
    </script>

";
        
        $__internal_365aa409041773d167eec52bcbbe1427313e655eefc5f2cffe42590c5bb11f6a->leave($__internal_365aa409041773d167eec52bcbbe1427313e655eefc5f2cffe42590c5bb11f6a_prof);

    }

    public function getTemplateName()
    {
        return "Admin/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 30,  101 => 29,  91 => 24,  86 => 22,  83 => 21,  81 => 20,  79 => 19,  75 => 18,  71 => 17,  67 => 16,  63 => 15,  59 => 14,  49 => 7,  45 => 6,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

 {% block sidebar %}
     <ul class=\"nav nav-pills nav-stacked\">
         <li><a href=\"#\" id=\"btn-perfil\">Mi perfil</a></li>
         <li class=\"\" ><a href=\"{{ path('personal_index')}}\" id=\"btn-personal\">Lista del Personal</a></li>
         <li class=\"\"><a href=\"{{ path('user_index')}}\" id=\"btn-usuarios\">Lista de Usuarios</a></li>
         <li class=\"dropdown\">
             <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\" >
                 Configuracion <span class=\"caret\"></span>
             </a>
             <ul class=\"dropdown-menu\">

                 <li><a href=\"{{ path(\"admin_servicio_index\") }}\" id=\"btn-servicios\">Servicios</a></li>
                 <li><a href=\"{{ path(\"admin_rol_index\") }}\" id=\"btn-roles\">Roles</a></li>
                 <li><a href=\"{{ path(\"admin_anestesia_index\") }}\" id=\"btn-anestesias\">Tipos de Anestesias</a></li>
                 <li><a href=\"{{ path(\"admin_asa_index\") }}\" id=\"btn-asa\">ASA</a></li>
                 <li><a href=\"{{ path(\"admin_quirofano_index\") }}\" id=\"btn-quirofano\">Quirófanos</a></li>
                 {% if is_granted('ROLE_ADMIN') %}
                     {#Esto es el abm de estado solo lo puede tocar el superadmin ... no tiene sentido que alguien del hospital lo modifique#}
                     <li class=\"divider\"></li>
                     <li><a href=\"{{ path('admin_estado_index') }}\">Estado Reserva</a></li>
                 {% endif %}
             </ul>
         </li>
     </ul>
 {% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script type=\"application/javascript\">
        \$(document).ready(function(){
            //no hya nada por ahora
        })
    </script>

{% endblock %}
", "Admin/layout.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/layout.html.twig");
    }
}
