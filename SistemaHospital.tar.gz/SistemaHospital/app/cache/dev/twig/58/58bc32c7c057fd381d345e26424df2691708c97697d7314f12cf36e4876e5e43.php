<?php

/* Admin/partials/servicio/index.html.twig */
class __TwigTemplate_6a86804e1bdb42986286439668e1ee2196e4c40e3bae86ad6c257d3ef0452b6f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Admin/layout.html.twig", "Admin/partials/servicio/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "Admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1f70bb714f0db5107187acdf51e9439992d7a620d4020d7496d0ef31f3d305f7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1f70bb714f0db5107187acdf51e9439992d7a620d4020d7496d0ef31f3d305f7->enter($__internal_1f70bb714f0db5107187acdf51e9439992d7a620d4020d7496d0ef31f3d305f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/partials/servicio/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1f70bb714f0db5107187acdf51e9439992d7a620d4020d7496d0ef31f3d305f7->leave($__internal_1f70bb714f0db5107187acdf51e9439992d7a620d4020d7496d0ef31f3d305f7_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_15dec264ab776f23c922b83a6ea8766e807822108ad43b5c5247cdcd098c7bde = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_15dec264ab776f23c922b83a6ea8766e807822108ad43b5c5247cdcd098c7bde->enter($__internal_15dec264ab776f23c922b83a6ea8766e807822108ad43b5c5247cdcd098c7bde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/partials/servicio/index.html.twig"));

        // line 4
        echo "    <h1>Servicios list</h1>
    ";
        // line 5
        if ( !twig_test_empty((isset($context["servicios"]) ? $context["servicios"] : $this->getContext($context, "servicios")))) {
            // line 6
            echo "    <table class=\"table table-striped table-hover\">
        <thead>
            <tr>
                <th>Id</th>
                <th>Tipo</th>
                <th>Descripcion</th>
                <th>Baja</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        ";
            // line 18
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["servicios"]) ? $context["servicios"] : $this->getContext($context, "servicios")));
            foreach ($context['_seq'] as $context["_key"] => $context["servicio"]) {
                // line 19
                echo "            <tr>
                <td><a href=\"";
                // line 20
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_servicio_show", array("id" => $this->getAttribute($context["servicio"], "id", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["servicio"], "id", array()), "html", null, true);
                echo "</a></td>
                <td>";
                // line 21
                echo twig_escape_filter($this->env, $this->getAttribute($context["servicio"], "tipo", array()), "html", null, true);
                echo "</td>
                <td>";
                // line 22
                echo twig_escape_filter($this->env, $this->getAttribute($context["servicio"], "descripcion", array()), "html", null, true);
                echo "</td>
                <td>";
                // line 23
                if ($this->getAttribute($context["servicio"], "baja", array())) {
                    echo "Yes";
                } else {
                    echo "No";
                }
                echo "</td>
                <td>
                    <a href=\"";
                // line 25
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_servicio_show", array("id" => $this->getAttribute($context["servicio"], "id", array()))), "html", null, true);
                echo "\">show</a>
                </td>
                <td>
                    <a href=\"";
                // line 28
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_servicio_edit", array("id" => $this->getAttribute($context["servicio"], "id", array()))), "html", null, true);
                echo "\">edit</a>
                </td>
            </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['servicio'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 32
            echo "        </tbody>
    </table>
    ";
        } else {
            // line 35
            echo "        <h2>No hay servicios incorporados</h2>
    ";
        }
        // line 37
        echo "    <a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_servicio_new");
        echo "\">Create a new servicio</a>

";
        
        $__internal_15dec264ab776f23c922b83a6ea8766e807822108ad43b5c5247cdcd098c7bde->leave($__internal_15dec264ab776f23c922b83a6ea8766e807822108ad43b5c5247cdcd098c7bde_prof);

    }

    public function getTemplateName()
    {
        return "Admin/partials/servicio/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 37,  110 => 35,  105 => 32,  95 => 28,  89 => 25,  80 => 23,  76 => 22,  72 => 21,  66 => 20,  63 => 19,  59 => 18,  45 => 6,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Admin/layout.html.twig' %}

{% block main %}
    <h1>Servicios list</h1>
    {% if servicios is not empty %}
    <table class=\"table table-striped table-hover\">
        <thead>
            <tr>
                <th>Id</th>
                <th>Tipo</th>
                <th>Descripcion</th>
                <th>Baja</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        {% for servicio in servicios %}
            <tr>
                <td><a href=\"{{ path('admin_servicio_show', { 'id': servicio.id }) }}\">{{ servicio.id }}</a></td>
                <td>{{ servicio.tipo }}</td>
                <td>{{ servicio.descripcion }}</td>
                <td>{% if servicio.baja %}Yes{% else %}No{% endif %}</td>
                <td>
                    <a href=\"{{ path('admin_servicio_show', { 'id': servicio.id }) }}\">show</a>
                </td>
                <td>
                    <a href=\"{{ path('admin_servicio_edit', { 'id': servicio.id }) }}\">edit</a>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    {% else %}
        <h2>No hay servicios incorporados</h2>
    {% endif %}
    <a href=\"{{ path('admin_servicio_new') }}\">Create a new servicio</a>

{% endblock %}
", "Admin/partials/servicio/index.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/partials/servicio/index.html.twig");
    }
}
