<?php

/* Admin/partials/estado/new.html.twig */
class __TwigTemplate_444b14efa4d3f9006afa048223981efa3418dc4dd87908390f49743fcaa7102b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Admin/layout.html.twig", "Admin/partials/estado/new.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "Admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_525dfed90bc47431a2829be3eb83bca157de276d79d2d9542d092a9922b83f7e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_525dfed90bc47431a2829be3eb83bca157de276d79d2d9542d092a9922b83f7e->enter($__internal_525dfed90bc47431a2829be3eb83bca157de276d79d2d9542d092a9922b83f7e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/partials/estado/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_525dfed90bc47431a2829be3eb83bca157de276d79d2d9542d092a9922b83f7e->leave($__internal_525dfed90bc47431a2829be3eb83bca157de276d79d2d9542d092a9922b83f7e_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_468c0608c4b75c7efd0cfcaa6c9ad53e86c861bbf54c0000935677965145f6f3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_468c0608c4b75c7efd0cfcaa6c9ad53e86c861bbf54c0000935677965145f6f3->enter($__internal_468c0608c4b75c7efd0cfcaa6c9ad53e86c861bbf54c0000935677965145f6f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/partials/estado/new.html.twig"));

        // line 4
        echo "    <h1>Estado creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_estado_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_468c0608c4b75c7efd0cfcaa6c9ad53e86c861bbf54c0000935677965145f6f3->leave($__internal_468c0608c4b75c7efd0cfcaa6c9ad53e86c861bbf54c0000935677965145f6f3_prof);

    }

    public function getTemplateName()
    {
        return "Admin/partials/estado/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Admin/layout.html.twig' %}

{% block main %}
    <h1>Estado creation</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input type=\"submit\" value=\"Create\" />
    {{ form_end(form) }}

    <ul>
        <li>
            <a href=\"{{ path('admin_estado_index') }}\">Back to the list</a>
        </li>
    </ul>
{% endblock %}
", "Admin/partials/estado/new.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/partials/estado/new.html.twig");
    }
}
