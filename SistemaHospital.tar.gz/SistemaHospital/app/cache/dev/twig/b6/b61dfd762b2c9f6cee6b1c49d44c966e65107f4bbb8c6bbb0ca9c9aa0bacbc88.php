<?php

/* FOSUserBundle::layout.html.twig */
class __TwigTemplate_2ebd5bb56558f74ca80e68487b7d20cdeca360d1929245d04bc6db301f06d312 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "FOSUserBundle::layout.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'fos_user_content' => array($this, 'block_fos_user_content'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c436d74d146cc4fbc797f04d4bf720fc826703cc27432775c68d85476e238067 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c436d74d146cc4fbc797f04d4bf720fc826703cc27432775c68d85476e238067->enter($__internal_c436d74d146cc4fbc797f04d4bf720fc826703cc27432775c68d85476e238067_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c436d74d146cc4fbc797f04d4bf720fc826703cc27432775c68d85476e238067->leave($__internal_c436d74d146cc4fbc797f04d4bf720fc826703cc27432775c68d85476e238067_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_e300f1af768a777f37d63cbb4114adec1c6e4aa6b83cdb31b2ce9515e9c10279 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e300f1af768a777f37d63cbb4114adec1c6e4aa6b83cdb31b2ce9515e9c10279->enter($__internal_e300f1af768a777f37d63cbb4114adec1c6e4aa6b83cdb31b2ce9515e9c10279_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "FOSUserBundle::layout.html.twig"));

        // line 4
        echo "    ";
        $this->displayBlock('fos_user_content', $context, $blocks);
        
        $__internal_e300f1af768a777f37d63cbb4114adec1c6e4aa6b83cdb31b2ce9515e9c10279->leave($__internal_e300f1af768a777f37d63cbb4114adec1c6e4aa6b83cdb31b2ce9515e9c10279_prof);

    }

    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_e07ae187fb49db069155222c3943e5e327b44760b67675a0dda7dbf0461d796e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e07ae187fb49db069155222c3943e5e327b44760b67675a0dda7dbf0461d796e->enter($__internal_e07ae187fb49db069155222c3943e5e327b44760b67675a0dda7dbf0461d796e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "FOSUserBundle::layout.html.twig"));

        // line 5
        echo "
    ";
        
        $__internal_e07ae187fb49db069155222c3943e5e327b44760b67675a0dda7dbf0461d796e->leave($__internal_e07ae187fb49db069155222c3943e5e327b44760b67675a0dda7dbf0461d796e_prof);

    }

    // line 9
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_17bb526d38fde47f881dbe0c789db58d3da0aac6cc7ea150a3b7dca0ccd7cc20 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_17bb526d38fde47f881dbe0c789db58d3da0aac6cc7ea150a3b7dca0ccd7cc20->enter($__internal_17bb526d38fde47f881dbe0c789db58d3da0aac6cc7ea150a3b7dca0ccd7cc20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "FOSUserBundle::layout.html.twig"));

        // line 10
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
";
        
        $__internal_17bb526d38fde47f881dbe0c789db58d3da0aac6cc7ea150a3b7dca0ccd7cc20->leave($__internal_17bb526d38fde47f881dbe0c789db58d3da0aac6cc7ea150a3b7dca0ccd7cc20_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 10,  63 => 9,  55 => 5,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block main %}
    {% block fos_user_content %}

    {% endblock %}
{% endblock %}

{% block javascripts %}
    {{ parent() }}
{% endblock %}
", "FOSUserBundle::layout.html.twig", "/var/www/html/taller/SistemaHospital/src/AppBundle/Resources/views/layout.html.twig");
    }
}
