<?php

/* Admin/partials/quirofano/index.html.twig */
class __TwigTemplate_3c67367198841896537a7662e0a2838096be399ceef21cc055e1d7d497a51dad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Admin/layout.html.twig", "Admin/partials/quirofano/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "Admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eb91635e5f9de61e1649ad2e7aa184788d238609fb9360851c1df5a4790ebae4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb91635e5f9de61e1649ad2e7aa184788d238609fb9360851c1df5a4790ebae4->enter($__internal_eb91635e5f9de61e1649ad2e7aa184788d238609fb9360851c1df5a4790ebae4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/partials/quirofano/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_eb91635e5f9de61e1649ad2e7aa184788d238609fb9360851c1df5a4790ebae4->leave($__internal_eb91635e5f9de61e1649ad2e7aa184788d238609fb9360851c1df5a4790ebae4_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_b69e474ec6803a35bfcb7a51fe416ab044152fcb65b176d9b5f8128cee6b27b2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b69e474ec6803a35bfcb7a51fe416ab044152fcb65b176d9b5f8128cee6b27b2->enter($__internal_b69e474ec6803a35bfcb7a51fe416ab044152fcb65b176d9b5f8128cee6b27b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/partials/quirofano/index.html.twig"));

        // line 4
        echo "    <h1>Quirofanos list</h1>
    ";
        // line 5
        if ( !twig_test_empty((isset($context["quirofanos"]) ? $context["quirofanos"] : $this->getContext($context, "quirofanos")))) {
            // line 6
            echo "    <table class=\"table table-striped table-hover\">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nombre</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        ";
            // line 16
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["quirofanos"]) ? $context["quirofanos"] : $this->getContext($context, "quirofanos")));
            foreach ($context['_seq'] as $context["_key"] => $context["quirofano"]) {
                // line 17
                echo "            <tr>
                <td><a href=\"";
                // line 18
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_quirofano_show", array("id" => $this->getAttribute($context["quirofano"], "id", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["quirofano"], "id", array()), "html", null, true);
                echo "</a></td>
                <td>";
                // line 19
                echo twig_escape_filter($this->env, $this->getAttribute($context["quirofano"], "nombre", array()), "html", null, true);
                echo "</td>
                <td>
                    <a href=\"";
                // line 21
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_quirofano_show", array("id" => $this->getAttribute($context["quirofano"], "id", array()))), "html", null, true);
                echo "\">show</a>
                </td>
                <td>
                    <a href=\"";
                // line 24
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_quirofano_edit", array("id" => $this->getAttribute($context["quirofano"], "id", array()))), "html", null, true);
                echo "\">edit</a>
                </td>
            </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['quirofano'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 28
            echo "        </tbody>
    </table>
    ";
        } else {
            // line 31
            echo "        <h2>No hay quirofanos incorporados</h2>
    ";
        }
        // line 33
        echo "        <a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_quirofano_new");
        echo "\">Create a new quirofano</a>
";
        
        $__internal_b69e474ec6803a35bfcb7a51fe416ab044152fcb65b176d9b5f8128cee6b27b2->leave($__internal_b69e474ec6803a35bfcb7a51fe416ab044152fcb65b176d9b5f8128cee6b27b2_prof);

    }

    public function getTemplateName()
    {
        return "Admin/partials/quirofano/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  100 => 33,  96 => 31,  91 => 28,  81 => 24,  75 => 21,  70 => 19,  64 => 18,  61 => 17,  57 => 16,  45 => 6,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Admin/layout.html.twig' %}

{% block main %}
    <h1>Quirofanos list</h1>
    {% if quirofanos is not empty %}
    <table class=\"table table-striped table-hover\">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nombre</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        {% for quirofano in quirofanos %}
            <tr>
                <td><a href=\"{{ path('admin_quirofano_show', { 'id': quirofano.id }) }}\">{{ quirofano.id }}</a></td>
                <td>{{ quirofano.nombre }}</td>
                <td>
                    <a href=\"{{ path('admin_quirofano_show', { 'id': quirofano.id }) }}\">show</a>
                </td>
                <td>
                    <a href=\"{{ path('admin_quirofano_edit', { 'id': quirofano.id }) }}\">edit</a>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    {% else %}
        <h2>No hay quirofanos incorporados</h2>
    {% endif %}
        <a href=\"{{ path('admin_quirofano_new') }}\">Create a new quirofano</a>
{% endblock %}
", "Admin/partials/quirofano/index.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/partials/quirofano/index.html.twig");
    }
}
