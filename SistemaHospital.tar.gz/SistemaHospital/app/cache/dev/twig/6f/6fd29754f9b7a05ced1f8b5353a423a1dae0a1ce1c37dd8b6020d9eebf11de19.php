<?php

/* Admin/partials/user/index.html.twig */
class __TwigTemplate_aeff8abdd60cc762e355d19a2c98b766af6d250e7a250dfaa43cc2e78721e6a2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Admin/layout.html.twig", "Admin/partials/user/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "Admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13d0103f1e95a9790be05a7c46fba350cd53d192a2840d7986338896addf4695 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_13d0103f1e95a9790be05a7c46fba350cd53d192a2840d7986338896addf4695->enter($__internal_13d0103f1e95a9790be05a7c46fba350cd53d192a2840d7986338896addf4695_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/partials/user/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_13d0103f1e95a9790be05a7c46fba350cd53d192a2840d7986338896addf4695->leave($__internal_13d0103f1e95a9790be05a7c46fba350cd53d192a2840d7986338896addf4695_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_88d0a1030913d977ec7a80e16d06b87553c7cd2016f95be917e155a545f22cb6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88d0a1030913d977ec7a80e16d06b87553c7cd2016f95be917e155a545f22cb6->enter($__internal_88d0a1030913d977ec7a80e16d06b87553c7cd2016f95be917e155a545f22cb6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Admin/partials/user/index.html.twig"));

        // line 4
        echo "    <h1>Lista de Usuarios</h1>
    ";
        // line 5
        if ( !twig_test_empty((isset($context["users"]) ? $context["users"] : $this->getContext($context, "users")))) {
            // line 6
            echo "    <table class=\"table table-striped table-hover \">
        <thead>
            <tr>
                <th>Id</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        ";
            // line 15
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["users"]) ? $context["users"] : $this->getContext($context, "users")));
            foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
                // line 16
                echo "            <tr>
                <td><a href=\"";
                // line 17
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_show", array("id" => $this->getAttribute($context["user"], "id", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["user"], "personal", array()), "nombre", array()), "html", null, true);
                echo "</a></td>
                <td>
                    <a href=\"";
                // line 19
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_show", array("id" => $this->getAttribute($context["user"], "id", array()))), "html", null, true);
                echo "\">show</a>
                </td>
                <td>
                    <a href=\"";
                // line 22
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_edit", array("id" => $this->getAttribute($context["user"], "id", array()))), "html", null, true);
                echo "\">edit</a>
                </td>
            </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 26
            echo "        </tbody>
    </table>
    ";
        } else {
            // line 29
            echo "        <h2>No hay usuarios incorporados</h2>
    ";
        }
        // line 31
        echo "
";
        
        $__internal_88d0a1030913d977ec7a80e16d06b87553c7cd2016f95be917e155a545f22cb6->leave($__internal_88d0a1030913d977ec7a80e16d06b87553c7cd2016f95be917e155a545f22cb6_prof);

    }

    public function getTemplateName()
    {
        return "Admin/partials/user/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 31,  91 => 29,  86 => 26,  76 => 22,  70 => 19,  63 => 17,  60 => 16,  56 => 15,  45 => 6,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Admin/layout.html.twig' %}

{% block main %}
    <h1>Lista de Usuarios</h1>
    {% if users is not empty %}
    <table class=\"table table-striped table-hover \">
        <thead>
            <tr>
                <th>Id</th>
                <th>Ver</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
        {% for user in users %}
            <tr>
                <td><a href=\"{{ path('user_show', { 'id': user.id }) }}\">{{ user.personal.nombre }}</a></td>
                <td>
                    <a href=\"{{ path('user_show', { 'id': user.id }) }}\">show</a>
                </td>
                <td>
                    <a href=\"{{ path('user_edit', { 'id': user.id }) }}\">edit</a>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
    {% else %}
        <h2>No hay usuarios incorporados</h2>
    {% endif %}

{% endblock %}
", "Admin/partials/user/index.html.twig", "/var/www/html/taller/SistemaHospital/app/Resources/views/Admin/partials/user/index.html.twig");
    }
}
